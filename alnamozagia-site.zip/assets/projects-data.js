// Project data: each project has 5 images + formatted details
window.PROJECTS_DATA = {
  villa1: {
    title: "فيلا سكنية خاصة - القاهرة الجديدة",
    category: "residential",
    location: "القاهرة الجديدة، التجمع الخامس",
    area: "450 م²",
    description: "فيلا سكنية دوبلكس بتصميم معماري عصري، تشمل 5 غرف نوم وحديقة خاصة ومسبح، نُفذت بالكامل من التصميم الإنشائي حتى التشطيبات النهائية خلال 14 شهرًا.",
    images: [
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900&q=80",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=900&q=80",
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900&q=80",
      "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=900&q=80",
      "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=900&q=80"
    ]
  },
  tower1: {
    title: "برج إداري وتجاري - وسط البلد",
    category: "commercial",
    location: "وسط البلد، القاهرة",
    area: "3200 م²",
    description: "برج إداري وتجاري من 12 طابقًا يضم مكاتب إدارية ومحلات تجارية بالدور الأرضي، بواجهات زجاجية عازلة للحرارة ونظام إطفاء وسلامة متكامل.",
    images: [
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=900&q=80",
      "https://images.unsplash.com/photo-1449844908441-8829872d2607?w=900&q=80",
      "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=900&q=80",
      "https://images.unsplash.com/photo-1554469384-e58fac16e23a?w=900&q=80",
      "https://images.unsplash.com/photo-1516156008625-3a9d6067fab5?w=900&q=80"
    ]
  },
  warehouse1: {
    title: "مستودع لوجستي - العاشر من رمضان",
    category: "industrial",
    location: "المنطقة الصناعية، العاشر من رمضان",
    area: "6000 م²",
    description: "منشأة تخزين لوجستية بهيكل معدني وأرضيات صناعية عالية التحمل، مجهزة بأنظمة تحميل وتفريغ ومساحات مكتبية ملحقة لإدارة العمليات.",
    images: [
      "https://images.unsplash.com/photo-1565043666747-69f6646db940?w=900&q=80",
      "https://images.unsplash.com/photo-1553413077-190dd305871c?w=900&q=80",
      "https://images.unsplash.com/photo-1601058268499-e52658b8bb88?w=900&q=80",
      "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?w=900&q=80",
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=900&q=80"
    ]
  },
  residential2: {
    title: "مجمع سكني متكامل",
    category: "residential",
    location: "6 أكتوبر، الجيزة",
    area: "8500 م² (أرض المشروع)",
    description: "مجمع سكني يضم 24 وحدة سكنية موزعة على 4 عمارات، مع مساحات خضراء مشتركة ومواقف سيارات وبوابة أمنية، نُفذ على مرحلتين.",
    images: [
      "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=900&q=80",
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=900&q=80",
      "https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?w=900&q=80",
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900&q=80",
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&q=80"
    ]
  },
  mall1: {
    title: "مول تجاري - الشيخ زايد",
    category: "commercial",
    location: "الشيخ زايد، الجيزة",
    area: "4800 م²",
    description: "مول تجاري بثلاثة طوابق يضم محلات تجزئة ومطاعم ومنطقة ترفيهية، بتصميم واجهات عصري ومسارات حركة داخلية مدروسة لراحة الزوار.",
    images: [
      "https://images.unsplash.com/photo-1555636222-cae831e670b3?w=900&q=80",
      "https://images.unsplash.com/photo-1519567241348-24431d474896?w=900&q=80",
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=900&q=80",
      "https://images.unsplash.com/photo-1481437156560-3205f6a55735?w=900&q=80",
      "https://images.unsplash.com/photo-1555529771-122e5d9f2341?w=900&q=80"
    ]
  },
  factory1: {
    title: "مصنع تعبئة وتغليف",
    category: "industrial",
    location: "المنطقة الصناعية الثالثة، بدر",
    area: "5200 م²",
    description: "منشأة صناعية لخطوط تعبئة وتغليف المواد الغذائية، مصممة وفق اشتراطات السلامة الغذائية مع عزل حراري وتهوية صناعية متكاملة.",
    images: [
      "https://images.unsplash.com/photo-1601058268499-e52658b8bb88?w=900&q=80",
      "https://images.unsplash.com/photo-1565608087341-404b25492fee?w=900&q=80",
      "https://images.unsplash.com/photo-1565087767399-cf0c8c9dcdaf?w=900&q=80",
      "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=900&q=80",
      "https://images.unsplash.com/photo-1531956656447-be71e0248983?w=900&q=80"
    ]
  },
  villa2: {
    title: "فيلا دوبلكس - الساحل الشمالي",
    category: "residential",
    location: "الساحل الشمالي",
    area: "380 م²",
    description: "فيلا ساحلية بتصميم معماري يواكب الطراز المتوسطي، مع تراس مطل على البحر ومسبح خاص، نُفذت بخامات مقاومة للرطوبة والملوحة.",
    images: [
      "https://images.unsplash.com/photo-1613977257363-707ba9348227?w=900&q=80",
      "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=900&q=80",
      "https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=900&q=80",
      "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=900&q=80",
      "https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=900&q=80"
    ]
  },
  office1: {
    title: "مبنى مكاتب إدارية",
    category: "commercial",
    location: "مدينة نصر، القاهرة",
    area: "2100 م²",
    description: "مبنى إداري من 6 طوابق مصمم لاستيعاب شركات متعددة، بمساحات مكتبية مرنة وقاعات اجتماعات وواجهة زجاجية عاكسة للحرارة.",
    images: [
      "https://images.unsplash.com/photo-1497366216548-37526070297c?w=900&q=80",
      "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=900&q=80",
      "https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=900&q=80",
      "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=900&q=80",
      "https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?w=900&q=80"
    ]
  },
  logistics1: {
    title: "منشأة تخزين ولوجستيات",
    category: "industrial",
    location: "طريق الإسكندرية الصحراوي",
    area: "7500 م²",
    description: "منشأة لوجستية متعددة الأغراض للتخزين والتوزيع، مزودة بأرصفة تحميل متعددة ونظام إدارة مخازن، ونُفذت وفق جدول زمني مضغوط لصالح عميل صناعي كبير.",
    images: [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=900&q=80",
      "https://images.unsplash.com/photo-1580674285054-bed31e145f59?w=900&q=80",
      "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=900&q=80",
      "https://images.unsplash.com/photo-1553413077-190dd305871c?w=900&q=80",
      "https://images.unsplash.com/photo-1565043666747-69f6646db940?w=900&q=80"
    ]
  }
};
