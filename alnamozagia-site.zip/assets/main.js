// Mobile nav toggle
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const navUl = document.querySelector('nav ul');
  if(toggle){
    toggle.addEventListener('click', () => navUl.classList.toggle('open'));
    navUl.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navUl.classList.remove('open')));
  }

  // Scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('visible');
        io.unobserve(entry.target);
      }
    });
  }, {threshold:0.12});
  revealEls.forEach(el => io.observe(el));

  // Gallery filter (portfolio page)
  const filterBtns = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      galleryItems.forEach(item => {
        if(filter === 'all' || item.dataset.category === filter){
          item.classList.remove('hidden');
        } else {
          item.classList.add('hidden');
        }
      });
    });
  });

  // Project modal gallery with slider
  const modal = document.querySelector('.project-modal');
  if(modal && window.PROJECTS_DATA){
    const track = modal.querySelector('.slider-track');
    const dotsWrap = modal.querySelector('.slider-dots');
    const counter = modal.querySelector('.slider-counter');
    const tagEl = modal.querySelector('.modal-tag');
    const titleEl = modal.querySelector('.modal-details h3');
    const locEl = modal.querySelector('[data-meta="location"] span');
    const areaEl = modal.querySelector('[data-meta="area"] span');
    const descEl = modal.querySelector('.modal-desc');
    const catLabels = {residential:'سكني', commercial:'تجاري', industrial:'صناعي'};

    let currentImages = [];
    let currentIndex = 0;

    function renderSlide(){
      track.style.transform = `translateX(${currentIndex * 100}%)`;
      counter.textContent = `${currentIndex + 1} / ${currentImages.length}`;
      dotsWrap.querySelectorAll('.slider-dot').forEach((d,i) => d.classList.toggle('active', i === currentIndex));
    }

    function openProject(id){
      const data = window.PROJECTS_DATA[id];
      if(!data) return;
      currentImages = data.images;
      currentIndex = 0;
      track.innerHTML = currentImages.map(src => `<img src="${src}" alt="${data.title}">`).join('');
      dotsWrap.innerHTML = currentImages.map((_,i) => `<span class="slider-dot"></span>`).join('');
      dotsWrap.querySelectorAll('.slider-dot').forEach((d,i) => d.addEventListener('click', () => { currentIndex = i; renderSlide(); }));
      tagEl.textContent = catLabels[data.category] || '';
      titleEl.textContent = data.title;
      locEl.textContent = data.location;
      areaEl.textContent = data.area;
      descEl.textContent = data.description;
      renderSlide();
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    }

    function closeModal(){
      modal.classList.remove('open');
      document.body.style.overflow = '';
    }

    function next(){ currentIndex = (currentIndex + 1) % currentImages.length; renderSlide(); }
    function prev(){ currentIndex = (currentIndex - 1 + currentImages.length) % currentImages.length; renderSlide(); }

    galleryItems.forEach(item => {
      item.addEventListener('click', () => openProject(item.dataset.projectId));
    });

    modal.querySelector('.slider-arrow.next').addEventListener('click', next);
    modal.querySelector('.slider-arrow.prev').addEventListener('click', prev);
    modal.querySelector('.modal-close').addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => { if(e.target === modal) closeModal(); });

    document.addEventListener('keydown', (e) => {
      if(!modal.classList.contains('open')) return;
      if(e.key === 'Escape') closeModal();
      if(e.key === 'ArrowLeft') next();
      if(e.key === 'ArrowRight') prev();
    });

    // Touch swipe support
    let touchStartX = 0;
    track.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; });
    track.addEventListener('touchend', (e) => {
      const diff = e.changedTouches[0].clientX - touchStartX;
      if(Math.abs(diff) > 50){ diff > 0 ? prev() : next(); }
    });
  }

  // Contact form (demo submit)
  const form = document.querySelector('#contact-form');
  if(form){
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = form.querySelector('.submit-btn');
      const original = btn.textContent;
      btn.textContent = 'تم الإرسال بنجاح ✓';
      btn.style.background = '#2f7a4d';
      form.reset();
      setTimeout(() => { btn.textContent = original; btn.style.background = ''; }, 3000);
    });
  }

  // Header shadow on scroll
  const header = document.querySelector('header');
  window.addEventListener('scroll', () => {
    if(window.scrollY > 20){ header.style.boxShadow = '0 4px 20px rgba(0,0,0,0.15)'; }
    else { header.style.boxShadow = 'none'; }
  });
});
